(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

(function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/ostrio_iron-router-helper-class/packages/ostrio_iron-rou //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
                                                                     // 1
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['ostrio:iron-router-helper-class'] = {};

})();

//# sourceMappingURL=ostrio_iron-router-helper-class.js.map
