(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var Router = Package['iron:router'].Router;
var RouteController = Package['iron:router'].RouteController;
var Iron = Package['iron:core'].Iron;

/* Package-scope variables */
var __coffeescriptShare, appDump;

(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                              //
// packages/hitchcott_app-dump/app-dump-server.coffee.js                                                        //
//                                                                                                              //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var Busboy, backup, fs, moment, path, restore;                                                                  // 1
                                                                                                                //
backup = Npm.require('mongodb-backup');                                                                         // 1
                                                                                                                //
restore = Npm.require('mongodb-restore');                                                                       // 1
                                                                                                                //
moment = Npm.require('moment');                                                                                 // 1
                                                                                                                //
Busboy = Npm.require("busboy");                                                                                 // 1
                                                                                                                //
path = Npm.require('path');                                                                                     // 1
                                                                                                                //
fs = Npm.require('fs');                                                                                         // 1
                                                                                                                //
appDump = {                                                                                                     // 1
  allow: function() {                                                                                           // 9
    return true;                                                                                                //
  }                                                                                                             //
};                                                                                                              //
                                                                                                                //
Router.map(function() {                                                                                         // 1
  return this.route('appDumpHTTP', {                                                                            //
    path: '/appDump',                                                                                           // 13
    where: 'server',                                                                                            // 13
    action: function() {                                                                                        // 13
      var application_root, backupOptions, base, busboy, e, filename, meteor_root, req, res, safe, self, separator, token;
      self = this;                                                                                              // 16
      req = this.request;                                                                                       // 16
      res = this.response;                                                                                      // 16
      if (req.method === 'GET') {                                                                               // 21
        if ((base = req.query).parser == null) {                                                                //
          base.parser = '';                                                                                     //
        }                                                                                                       //
        check(req.query.parser, String);                                                                        // 23
        self.options = {                                                                                        // 23
          parser: req.query.parser                                                                              // 27
        };                                                                                                      //
        if (req.query.collections) {                                                                            // 30
          check(req.query.collections, String);                                                                 // 31
          self.options.collections = req.query.collections.split(',').map(function(col) {                       // 31
            return col.trim();                                                                                  //
          });                                                                                                   //
          if (self.options.collections.length === 0) {                                                          // 36
            self.options.collections = null;                                                                    // 37
          }                                                                                                     //
        }                                                                                                       //
        if (req.query.query) {                                                                                  // 40
          check(req.query.query, String);                                                                       // 41
          try {                                                                                                 // 42
            self.options.query = JSON.parse(req.query.query);                                                   // 43
          } catch (_error) {                                                                                    //
            e = _error;                                                                                         // 45
            res.statusCode = 401;                                                                               // 45
            res.end("Failed to parse JSON Query");                                                              // 45
            return false;                                                                                       // 47
          }                                                                                                     //
        }                                                                                                       //
        token = req.query.token || '';                                                                          // 23
        check(token, String);                                                                                   // 23
        self.user = Meteor.users.findOne({                                                                      // 23
          "services.resume.loginTokens.hashedToken": Accounts._hashLoginToken(token)                            // 53
        });                                                                                                     //
        if (!appDump.allow.apply(self)) {                                                                       // 55
          res.statusCode = 401;                                                                                 // 56
          res.end('Unauthorized');                                                                              // 56
          return false;                                                                                         // 58
        }                                                                                                       //
        meteor_root = fs.realpathSync(process.cwd() + '/../');                                                  // 23
        application_root = fs.realpathSync(meteor_root + '/../');                                               // 23
        if (path.basename(fs.realpathSync(meteor_root + '/../../../')) === '.meteor') {                         // 63
          application_root = fs.realpathSync(meteor_root + '/../../../../');                                    // 64
        }                                                                                                       //
        separator = application_root.indexOf('\\') > -1 ? '\\' : '/';                                           // 23
        if (req.query.filename) {                                                                               // 68
          check(req.query.filename, String);                                                                    // 69
          filename = req.query.filename.replace(/[^a-z0-9_-]/gi, '_') + '.tar';                                 // 69
        }                                                                                                       //
        if (!filename) {                                                                                        // 72
          safe = {                                                                                              // 73
            host: req.headers.host.replace(/[^a-z0-9]/gi, '-').toLowerCase(),                                   // 74
            app: application_root.split(separator).pop().replace(/[^a-z0-9]/gi, '-').toLowerCase(),             // 74
            date: moment().format("YY-MM-DD_HH-mm-ss"),                                                         // 74
            parser: self.options.parser || 'bson'                                                               // 74
          };                                                                                                    //
          filename = "meteordump_" + safe.parser + "_" + safe.app + "_" + safe.host + "_" + safe.date + ".tar";
        }                                                                                                       //
        res.statusCode = 200;                                                                                   // 23
        res.setHeader('Content-disposition', "attachment; filename=" + filename);                               // 23
        backupOptions = {                                                                                       // 23
          uri: process.env.MONGO_URL,                                                                           // 85
          stream: res,                                                                                          // 85
          tar: 'dump.tar',                                                                                      // 85
          query: self.options.query,                                                                            // 85
          parser: self.options.parser                                                                           // 85
        };                                                                                                      //
        if (self.options.collections) {                                                                         // 91
          backupOptions.collections = self.options.collections;                                                 // 92
        }                                                                                                       //
        backup(backupOptions);                                                                                  // 23
      }                                                                                                         //
      if (req.method === 'POST') {                                                                              // 97
        busboy = new Busboy({                                                                                   // 98
          headers: req.headers,                                                                                 // 99
          limits: {                                                                                             // 99
            fields: 3,                                                                                          // 101
            files: 1                                                                                            // 101
          }                                                                                                     //
        });                                                                                                     //
        token = void 0;                                                                                         // 98
        self.options = {                                                                                        // 98
          drop: false,                                                                                          // 106
          parser: 'bson'                                                                                        // 106
        };                                                                                                      //
        busboy.on("field", function(fieldname, val) {                                                           // 98
          if (fieldname === 'token') {                                                                          // 110
            check(val, String);                                                                                 // 111
            token = val;                                                                                        // 111
          }                                                                                                     //
          if (fieldname === 'drop') {                                                                           // 113
            self.options.drop = true;                                                                           // 114
          }                                                                                                     //
          if (fieldname === 'parser') {                                                                         // 115
            check(val, String);                                                                                 // 117
            return self.options.parser = val;                                                                   //
          }                                                                                                     //
        });                                                                                                     //
        busboy.on("file", Meteor.bindEnvironment(function(fieldname, file, filename) {                          // 98
          var restoreOptions;                                                                                   // 122
          if (fieldname !== 'appDumpUpload' || filename.split('.').pop() !== 'tar') {                           // 122
            res.statusCode = 400;                                                                               // 123
            res.end('Incorrect file type. Expecting a file ending in .tar');                                    // 123
            return false;                                                                                       // 125
          }                                                                                                     //
          if (file == null) {                                                                                   // 127
            res.statusCode = 400;                                                                               // 128
            res.end('File not found');                                                                          // 128
            return false;                                                                                       // 130
          }                                                                                                     //
          self.user = Meteor.users.findOne({                                                                    // 122
            "services.resume.loginTokens.hashedToken": Accounts._hashLoginToken(token)                          // 132
          });                                                                                                   //
          if (!appDump.allow.apply(self)) {                                                                     // 134
            res.statusCode = 401;                                                                               // 135
            res.end('Unauthorized');                                                                            // 135
            return false;                                                                                       // 137
          }                                                                                                     //
          restoreOptions = {                                                                                    // 122
            uri: process.env.MONGO_URL,                                                                         // 140
            stream: file,                                                                                       // 140
            parser: self.options.parser,                                                                        // 140
            dropCollections: self.options.drop,                                                                 // 140
            callback: function() {                                                                              // 140
              return res.end();                                                                                 //
            }                                                                                                   //
          };                                                                                                    //
          return restore(restoreOptions);                                                                       //
        }));                                                                                                    //
        return req.pipe(busboy);                                                                                //
      }                                                                                                         //
    }                                                                                                           //
  });                                                                                                           //
});                                                                                                             // 11
                                                                                                                //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['hitchcott:app-dump'] = {
  appDump: appDump
};

})();

//# sourceMappingURL=hitchcott_app-dump.js.map
