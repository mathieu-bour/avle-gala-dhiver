(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

(function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/fezvrasta_bootstrap-material-design-noicons/packages/fez //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
                                                                     // 1
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['fezvrasta:bootstrap-material-design-noicons'] = {};

})();

//# sourceMappingURL=fezvrasta_bootstrap-material-design-noicons.js.map
