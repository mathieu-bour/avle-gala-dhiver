(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['ostrio:iron-router-meta'] = {};

})();

//# sourceMappingURL=ostrio_iron-router-meta.js.map
