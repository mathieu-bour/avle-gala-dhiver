(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

(function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/steeve_jquery-barcode/packages/steeve_jquery-barcode.js  //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
                                                                     // 1
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['steeve:jquery-barcode'] = {};

})();

//# sourceMappingURL=steeve_jquery-barcode.js.map
